// generated from rosidl_generator_c/resource/idl.h.em
// with input from autoware_auto_control_msgs:msg\AckermannControlCommand.idl
// generated code does not contain a copyright notice

#ifndef AUTOWARE_AUTO_CONTROL_MSGS__MSG__ACKERMANN_CONTROL_COMMAND_H_
#define AUTOWARE_AUTO_CONTROL_MSGS__MSG__ACKERMANN_CONTROL_COMMAND_H_

#include "autoware_auto_control_msgs/msg/detail/ackermann_control_command__struct.h"
#include "autoware_auto_control_msgs/msg/detail/ackermann_control_command__functions.h"
#include "autoware_auto_control_msgs/msg/detail/ackermann_control_command__type_support.h"

#endif  // AUTOWARE_AUTO_CONTROL_MSGS__MSG__ACKERMANN_CONTROL_COMMAND_H_
