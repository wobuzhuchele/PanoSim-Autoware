// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef AUTOWARE_AUTO_CONTROL_MSGS__MSG__ACKERMANN_CONTROL_COMMAND_HPP_
#define AUTOWARE_AUTO_CONTROL_MSGS__MSG__ACKERMANN_CONTROL_COMMAND_HPP_

#include "autoware_auto_control_msgs/msg/detail/ackermann_control_command__struct.hpp"
#include "autoware_auto_control_msgs/msg/detail/ackermann_control_command__builder.hpp"
#include "autoware_auto_control_msgs/msg/detail/ackermann_control_command__traits.hpp"
#include "autoware_auto_control_msgs/msg/detail/ackermann_control_command__type_support.hpp"

#endif  // AUTOWARE_AUTO_CONTROL_MSGS__MSG__ACKERMANN_CONTROL_COMMAND_HPP_
