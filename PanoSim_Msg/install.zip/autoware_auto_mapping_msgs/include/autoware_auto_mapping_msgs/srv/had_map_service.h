// generated from rosidl_generator_c/resource/idl.h.em
// with input from autoware_auto_mapping_msgs:srv\HADMapService.idl
// generated code does not contain a copyright notice

#ifndef AUTOWARE_AUTO_MAPPING_MSGS__SRV__HAD_MAP_SERVICE_H_
#define AUTOWARE_AUTO_MAPPING_MSGS__SRV__HAD_MAP_SERVICE_H_

#include "autoware_auto_mapping_msgs/srv/detail/had_map_service__struct.h"
#include "autoware_auto_mapping_msgs/srv/detail/had_map_service__functions.h"
#include "autoware_auto_mapping_msgs/srv/detail/had_map_service__type_support.h"

#endif  // AUTOWARE_AUTO_MAPPING_MSGS__SRV__HAD_MAP_SERVICE_H_
