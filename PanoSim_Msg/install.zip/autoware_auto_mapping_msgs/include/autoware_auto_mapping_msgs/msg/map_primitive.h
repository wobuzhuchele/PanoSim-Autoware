// generated from rosidl_generator_c/resource/idl.h.em
// with input from autoware_auto_mapping_msgs:msg\MapPrimitive.idl
// generated code does not contain a copyright notice

#ifndef AUTOWARE_AUTO_MAPPING_MSGS__MSG__MAP_PRIMITIVE_H_
#define AUTOWARE_AUTO_MAPPING_MSGS__MSG__MAP_PRIMITIVE_H_

#include "autoware_auto_mapping_msgs/msg/detail/map_primitive__struct.h"
#include "autoware_auto_mapping_msgs/msg/detail/map_primitive__functions.h"
#include "autoware_auto_mapping_msgs/msg/detail/map_primitive__type_support.h"

#endif  // AUTOWARE_AUTO_MAPPING_MSGS__MSG__MAP_PRIMITIVE_H_
