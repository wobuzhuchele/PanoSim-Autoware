// generated from rosidl_generator_c/resource/idl.h.em
// with input from autoware_auto_mapping_msgs:msg\HADMapSegment.idl
// generated code does not contain a copyright notice

#ifndef AUTOWARE_AUTO_MAPPING_MSGS__MSG__HAD_MAP_SEGMENT_H_
#define AUTOWARE_AUTO_MAPPING_MSGS__MSG__HAD_MAP_SEGMENT_H_

#include "autoware_auto_mapping_msgs/msg/detail/had_map_segment__struct.h"
#include "autoware_auto_mapping_msgs/msg/detail/had_map_segment__functions.h"
#include "autoware_auto_mapping_msgs/msg/detail/had_map_segment__type_support.h"

#endif  // AUTOWARE_AUTO_MAPPING_MSGS__MSG__HAD_MAP_SEGMENT_H_
