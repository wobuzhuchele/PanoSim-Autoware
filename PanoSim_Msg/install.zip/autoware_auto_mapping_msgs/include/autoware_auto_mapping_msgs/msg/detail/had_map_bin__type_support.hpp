// generated from rosidl_generator_cpp/resource/idl__type_support.hpp.em
// with input from autoware_auto_mapping_msgs:msg\HADMapBin.idl
// generated code does not contain a copyright notice

#ifndef AUTOWARE_AUTO_MAPPING_MSGS__MSG__DETAIL__HAD_MAP_BIN__TYPE_SUPPORT_HPP_
#define AUTOWARE_AUTO_MAPPING_MSGS__MSG__DETAIL__HAD_MAP_BIN__TYPE_SUPPORT_HPP_

#include "rosidl_typesupport_interface/macros.h"

#include "autoware_auto_mapping_msgs/msg/rosidl_generator_cpp__visibility_control.hpp"

#include "rosidl_typesupport_cpp/message_type_support.hpp"

#ifdef __cplusplus
extern "C"
{
#endif
// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_CPP_PUBLIC_autoware_auto_mapping_msgs
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_cpp,
  autoware_auto_mapping_msgs,
  msg,
  HADMapBin
)();
#ifdef __cplusplus
}
#endif

#endif  // AUTOWARE_AUTO_MAPPING_MSGS__MSG__DETAIL__HAD_MAP_BIN__TYPE_SUPPORT_HPP_
