// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef AUTOWARE_AUTO_MAPPING_MSGS__MSG__HAD_MAP_BIN_HPP_
#define AUTOWARE_AUTO_MAPPING_MSGS__MSG__HAD_MAP_BIN_HPP_

#include "autoware_auto_mapping_msgs/msg/detail/had_map_bin__struct.hpp"
#include "autoware_auto_mapping_msgs/msg/detail/had_map_bin__builder.hpp"
#include "autoware_auto_mapping_msgs/msg/detail/had_map_bin__traits.hpp"
#include "autoware_auto_mapping_msgs/msg/detail/had_map_bin__type_support.hpp"

#endif  // AUTOWARE_AUTO_MAPPING_MSGS__MSG__HAD_MAP_BIN_HPP_
