// generated from rosidl_generator_c/resource/idl.h.em
// with input from autoware_auto_perception_msgs:msg\ClassifiedRoiArray.idl
// generated code does not contain a copyright notice

#ifndef AUTOWARE_AUTO_PERCEPTION_MSGS__MSG__CLASSIFIED_ROI_ARRAY_H_
#define AUTOWARE_AUTO_PERCEPTION_MSGS__MSG__CLASSIFIED_ROI_ARRAY_H_

#include "autoware_auto_perception_msgs/msg/detail/classified_roi_array__struct.h"
#include "autoware_auto_perception_msgs/msg/detail/classified_roi_array__functions.h"
#include "autoware_auto_perception_msgs/msg/detail/classified_roi_array__type_support.h"

#endif  // AUTOWARE_AUTO_PERCEPTION_MSGS__MSG__CLASSIFIED_ROI_ARRAY_H_
