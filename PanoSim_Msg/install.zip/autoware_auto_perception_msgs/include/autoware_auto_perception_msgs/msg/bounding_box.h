// generated from rosidl_generator_c/resource/idl.h.em
// with input from autoware_auto_perception_msgs:msg\BoundingBox.idl
// generated code does not contain a copyright notice

#ifndef AUTOWARE_AUTO_PERCEPTION_MSGS__MSG__BOUNDING_BOX_H_
#define AUTOWARE_AUTO_PERCEPTION_MSGS__MSG__BOUNDING_BOX_H_

#include "autoware_auto_perception_msgs/msg/detail/bounding_box__struct.h"
#include "autoware_auto_perception_msgs/msg/detail/bounding_box__functions.h"
#include "autoware_auto_perception_msgs/msg/detail/bounding_box__type_support.h"

#endif  // AUTOWARE_AUTO_PERCEPTION_MSGS__MSG__BOUNDING_BOX_H_
