// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef AUTOWARE_AUTO_PERCEPTION_MSGS__MSG__CLASSIFIED_ROI_HPP_
#define AUTOWARE_AUTO_PERCEPTION_MSGS__MSG__CLASSIFIED_ROI_HPP_

#include "autoware_auto_perception_msgs/msg/detail/classified_roi__struct.hpp"
#include "autoware_auto_perception_msgs/msg/detail/classified_roi__builder.hpp"
#include "autoware_auto_perception_msgs/msg/detail/classified_roi__traits.hpp"
#include "autoware_auto_perception_msgs/msg/detail/classified_roi__type_support.hpp"

#endif  // AUTOWARE_AUTO_PERCEPTION_MSGS__MSG__CLASSIFIED_ROI_HPP_
