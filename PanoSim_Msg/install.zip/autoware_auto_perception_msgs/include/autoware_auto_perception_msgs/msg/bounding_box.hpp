// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef AUTOWARE_AUTO_PERCEPTION_MSGS__MSG__BOUNDING_BOX_HPP_
#define AUTOWARE_AUTO_PERCEPTION_MSGS__MSG__BOUNDING_BOX_HPP_

#include "autoware_auto_perception_msgs/msg/detail/bounding_box__struct.hpp"
#include "autoware_auto_perception_msgs/msg/detail/bounding_box__builder.hpp"
#include "autoware_auto_perception_msgs/msg/detail/bounding_box__traits.hpp"
#include "autoware_auto_perception_msgs/msg/detail/bounding_box__type_support.hpp"

#endif  // AUTOWARE_AUTO_PERCEPTION_MSGS__MSG__BOUNDING_BOX_HPP_
