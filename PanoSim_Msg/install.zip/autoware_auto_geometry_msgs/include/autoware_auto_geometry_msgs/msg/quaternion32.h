// generated from rosidl_generator_c/resource/idl.h.em
// with input from autoware_auto_geometry_msgs:msg\Quaternion32.idl
// generated code does not contain a copyright notice

#ifndef AUTOWARE_AUTO_GEOMETRY_MSGS__MSG__QUATERNION32_H_
#define AUTOWARE_AUTO_GEOMETRY_MSGS__MSG__QUATERNION32_H_

#include "autoware_auto_geometry_msgs/msg/detail/quaternion32__struct.h"
#include "autoware_auto_geometry_msgs/msg/detail/quaternion32__functions.h"
#include "autoware_auto_geometry_msgs/msg/detail/quaternion32__type_support.h"

#endif  // AUTOWARE_AUTO_GEOMETRY_MSGS__MSG__QUATERNION32_H_
